Get XTK!
========

All XTK builds.

* **xtk.js** The latest stable release.
* **xtk_edge.js** The bleeding edge version of XTK built on every change.
* **xtk_nightly.js** The bleeding edge version of XTK built every night.
* **xtk_xdat.gui.js** A modified version of DAT.GUI which clips directly into XTK.
* .. and all previous releases.

NOTE: Right now it is recommended to use **xtk_edge.js** since the API changed.